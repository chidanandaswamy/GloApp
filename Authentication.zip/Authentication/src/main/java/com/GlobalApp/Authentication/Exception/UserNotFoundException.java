package com.GlobalApp.Authentication.Exception;

public class UserNotFoundException extends Exception{
}

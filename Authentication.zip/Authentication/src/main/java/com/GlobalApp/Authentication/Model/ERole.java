package com.GlobalApp.Authentication.Model;

public enum ERole {
  ADMIN, USER

}
